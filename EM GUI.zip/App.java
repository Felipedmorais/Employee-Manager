import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new App().createAndShowGui());
    }

    private void createAndShowGui() {
        JFrame frame = new JFrame("Prototype");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 750);
        frame.setLocationRelativeTo(null);

        JPanel container = new JPanel(new CardLayout());

        JPanel telaCadastro = criarTelaCadastro(container);
        DashboardGerentePanel dash = new DashboardGerentePanel(container);

        container.add(telaCadastro, "LOGIN");
        container.add(dash.getPanel(), "DASH");
        container.add(new TelaCadastrarUsuarioPanel(container).getPanel(), "CAD_USUARIO");

        frame.add(container);
        frame.setVisible(true);
    }

    private JPanel criarTelaCadastro(JPanel container) {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        painel.setBackground(new Color(245, 245, 245));
        painel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titulo = new JLabel("CRIAR CONTA");
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(titulo);
        painel.add(Box.createVerticalStrut(25));

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(320, 2));
        sep.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(sep);
        painel.add(Box.createVerticalStrut(30));

        Font labelFont = new Font("Arial", Font.PLAIN, 13);
        Font inputFont = new Font("Arial", Font.PLAIN, 16);

        JTextField email = new JTextField();
        JTextField nome = new JTextField();
        JTextField sobrenome = new JTextField();
        JPasswordField senha = new JPasswordField();
        JPasswordField confirmarSenha = new JPasswordField();

        painel.add(criarCampo("E-MAIL", email, labelFont, inputFont));
        painel.add(Box.createVerticalStrut(14));
        painel.add(criarCampo("NOME", nome, labelFont, inputFont));
        painel.add(Box.createVerticalStrut(14));
        painel.add(criarCampo("SOBRENOME", sobrenome, labelFont, inputFont));
        painel.add(Box.createVerticalStrut(14));
        painel.add(criarCampo("SENHA", senha, labelFont, inputFont));
        painel.add(Box.createVerticalStrut(14));
        painel.add(criarCampo("CONFIRMAR SENHA", confirmarSenha, labelFont, inputFont));

        painel.add(Box.createVerticalStrut(22));

        JCheckBox termos = new JCheckBox("Li e aceito os Termos de Uso");
        termos.setBackground(new Color(245, 245, 245));
        termos.setFont(new Font("Arial", Font.PLAIN, 13));
        termos.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(termos);
        painel.add(Box.createVerticalStrut(26));

        JButton criarConta = new JButton("Criar conta");
        criarConta.setFont(new Font("Arial", Font.BOLD, 16));
        criarConta.setBackground(new Color(40, 115, 255));
        criarConta.setForeground(Color.WHITE);
        criarConta.setFocusPainted(false);
        criarConta.setPreferredSize(new Dimension(320, 45));
        criarConta.setMaximumSize(new Dimension(320, 45));
        criarConta.setAlignmentX(Component.CENTER_ALIGNMENT);
        painel.add(criarConta);

        painel.add(Box.createVerticalStrut(15));

        // Início da correção: Envolver o JLabel em um JPanel com FlowLayout
        // centralizado

        // Novo JPanel para centralizar o texto de login/entrada
        JPanel loginWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        loginWrapper.setBackground(new Color(245, 245, 245));
        loginWrapper.setAlignmentX(Component.CENTER_ALIGNMENT); // Mantém o wrapper centralizado no BoxLayout.Y_AXIS

        JLabel loginLabel = new JLabel(
                "<html><u>Já tem uma conta? Entrar...</u></html>");
        loginLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        loginLabel.setForeground(new Color(40, 115, 255));
        // O alinhamento horizontal não é mais estritamente necessário no JLabel,
        // mas o FlowLayout.CENTER no wrapper garante a centralização.
        // loginLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Removido para
        // simplificar

        loginWrapper.add(loginLabel);
        painel.add(loginWrapper);

        // Fim da correção

        painel.add(Box.createVerticalStrut(20));

        JPanel rodapeWrapper = new JPanel();
        rodapeWrapper.setLayout(new BoxLayout(rodapeWrapper, BoxLayout.X_AXIS));
        rodapeWrapper.setBackground(new Color(245, 245, 245));
        rodapeWrapper.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel rodape = new JLabel(
                "<html><p style='width:320px; text-align:center;'>"
                        + "Ao aceitar nossos Termos de Uso, você confirma ter lido e "
                        + "compreendido as condições apresentadas, concordando "
                        + "com nossas políticas de privacidade e o tratamento de seus "
                        + "dados para fins de funcionamento, segurança e aprimoramento "
                        + "da plataforma. Também reconhece que o uso dos nossos serviços "
                        + "deve seguir as normas e boas práticas descritas."
                        + "</p></html>");

        rodape.setFont(new Font("Arial", Font.PLAIN, 11));
        rodape.setHorizontalAlignment(SwingConstants.CENTER);

        rodapeWrapper.add(Box.createHorizontalGlue());
        rodapeWrapper.add(rodape);
        rodapeWrapper.add(Box.createHorizontalGlue());

        painel.add(rodapeWrapper);

        criarConta.addActionListener(e -> {
            CardLayout cl = (CardLayout) container.getLayout();
            cl.show(container, "DASH");
        });

        return painel;
    }

    private static JPanel criarCampo(String nome, JComponent input, Font labelFont, Font inputFont) {
        JPanel bloco = new JPanel();
        bloco.setLayout(new BoxLayout(bloco, BoxLayout.Y_AXIS));
        bloco.setBackground(new Color(245, 245, 245));
        bloco.setMaximumSize(new Dimension(320, 65));
        bloco.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel label = new JLabel(nome);
        label.setFont(labelFont);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        input.setFont(inputFont);
        input.setPreferredSize(new Dimension(320, 34));
        input.setMaximumSize(new Dimension(320, 34));
        input.setAlignmentX(Component.CENTER_ALIGNMENT);

        bloco.add(label);
        bloco.add(Box.createVerticalStrut(6));
        bloco.add(input);

        return bloco;
    }
}

class DashboardGerentePanel {
    private JPanel painelPrincipal;
    private JPanel container;

    private static final Color AZUL_PRIMARIO = new Color(40, 115, 255);
    private static final Color CINZA_FUNDO_MENU = new Color(30, 45, 60);
    private static final Color CINZA_FUNDO_AREA = new Color(250, 250, 250);
    private static final Color AZUL_ATIVO = new Color(60, 130, 255);

    public DashboardGerentePanel(JPanel container) {
        this.container = container;
        montar();
    }

    private void montar() {

        painelPrincipal = new JPanel(new BorderLayout());
        painelPrincipal.setBackground(CINZA_FUNDO_AREA);

        // Topo
        JLabel topo = new JLabel("Employee Manager System", SwingConstants.CENTER);
        topo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        topo.setBorder(new EmptyBorder(15, 0, 20, 0));
        painelPrincipal.add(topo, BorderLayout.NORTH);

        // Menu lateral
        JPanel menuLateral = new JPanel(new BorderLayout());
        menuLateral.setPreferredSize(new Dimension(230, 0));
        menuLateral.setBackground(CINZA_FUNDO_MENU);

        JPanel botoesWrapper = new JPanel();
        botoesWrapper.setLayout(new BoxLayout(botoesWrapper, BoxLayout.Y_AXIS));
        botoesWrapper.setBackground(CINZA_FUNDO_MENU);
        botoesWrapper.setBorder(new EmptyBorder(25, 15, 15, 15));

        String[][] dadosBotoes = {
                { "Cadastrar Funcionário", "👤" },
                { "Lista Funcionários", "📋" },
                { "Times", "👥" },
                { "Relatórios", "📈" },
                { "Configurações", "⚙️" }
        };

        JButton botaoLista = null;

        for (String[] dados : dadosBotoes) {
            JButton btn = criarBotaoMenu(dados[0], dados[1]);
            botoesWrapper.add(btn);
            botoesWrapper.add(Box.createVerticalStrut(12));

            if (dados[0].equals("Lista Funcionários"))
                botaoLista = btn;

            if (dados[0].equals("Cadastrar Funcionário")) {
                btn.addActionListener(e -> {
                    CardLayout cl = (CardLayout) container.getLayout();
                    cl.show(container, "CAD_USUARIO");
                });
            }
        }

        // Deixar "Lista Funcionários" como ativo
        if (botaoLista != null) {
            botaoLista.setBackground(AZUL_ATIVO);
        }

        // Botão sair
        JButton sair = new JButton("Sair");
        sair.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sair.setForeground(Color.WHITE);
        sair.setBackground(new Color(180, 55, 55));
        sair.setFocusPainted(false);
        sair.setPreferredSize(new Dimension(200, 40));
        sair.setMaximumSize(new Dimension(220, 40));
        sair.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel sairWrapper = new JPanel();
        sairWrapper.setBackground(CINZA_FUNDO_MENU);
        sairWrapper.add(sair);

        menuLateral.add(botoesWrapper, BorderLayout.NORTH);
        menuLateral.add(sairWrapper, BorderLayout.SOUTH);

        painelPrincipal.add(menuLateral, BorderLayout.WEST);

        // Centro
        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setBackground(CINZA_FUNDO_AREA);
        centro.setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel titulo = new JLabel("Funcionários Recentes");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        String[] colunas = { "ID", "Nome", "Cargo", "Salário" };
        DefaultTableModel model = new DefaultTableModel(colunas, 0);

        JTable tabela = new JTable(model);
        tabela.setRowHeight(26);
        tabela.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabela.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
        tabela.getTableHeader().setBackground(new Color(230, 230, 230));

        // Centralizar texto das células
        DefaultTableCellRenderer centralizado = new DefaultTableCellRenderer();
        centralizado.setHorizontalAlignment(SwingConstants.CENTER);

        for (int i = 0; i < tabela.getColumnCount(); i++) {
            tabela.getColumnModel().getColumn(i).setCellRenderer(centralizado);
        }

        model.addRow(new Object[] { "34789", "Ana", "Dev", "3500" });
        model.addRow(new Object[] { "98131", "Bruno", "Suporte", "2800" });
        model.addRow(new Object[] { "29844", "Carlos", "Estágio Faturamento", "925" });

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setPreferredSize(new Dimension(600, 260));
        scroll.setMaximumSize(new Dimension(700, 300));
        scroll.setAlignmentX(Component.CENTER_ALIGNMENT);

        centro.add(titulo);
        centro.add(Box.createVerticalStrut(20));
        centro.add(scroll);

        painelPrincipal.add(centro, BorderLayout.CENTER);

        // Ações
        sair.addActionListener(e -> {
            CardLayout cl = (CardLayout) container.getLayout();
            cl.show(container, "LOGIN");
        });
    }

    private JButton criarBotaoMenu(String texto, String icone) {
        JButton btn = new JButton(icone + "  " + texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setForeground(Color.WHITE);
        btn.setBackground(CINZA_FUNDO_MENU);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setMaximumSize(new Dimension(220, 45));
        return btn;
    }

    public JPanel getPanel() {
        return painelPrincipal;
    }
}

class TelaCadastrarUsuarioPanel {

    private JPanel painelPrincipal;
    private JPanel container;

    public TelaCadastrarUsuarioPanel(JPanel container) {
        this.container = container;
        montar();
    }

    private void montar() {
        painelPrincipal = new JPanel();
        painelPrincipal.setLayout(new BoxLayout(painelPrincipal, BoxLayout.Y_AXIS));
        painelPrincipal.setBackground(new Color(245, 245, 245));
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        // Garante que o painel principal tente se alinhar ao centro se estiver dentro
        // de outro container
        painelPrincipal.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titulo = new JLabel("CADASTRAR USUÁRIO");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT); // Centraliza o Título

        painelPrincipal.add(titulo);
        painelPrincipal.add(Box.createVerticalStrut(25));

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(350, 2));
        sep.setAlignmentX(Component.CENTER_ALIGNMENT); // CORREÇÃO: Centraliza o Separador
        painelPrincipal.add(sep);
        painelPrincipal.add(Box.createVerticalStrut(25));

        // Campos
        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 16);

        JTextField nome = new JTextField();
        JTextField cargo = new JTextField();
        JTextField salario = new JTextField();

        painelPrincipal.add(criarCampo("Nome do Funcionário", nome, labelFont, inputFont));
        painelPrincipal.add(Box.createVerticalStrut(14));

        painelPrincipal.add(criarCampo("Cargo", cargo, labelFont, inputFont));
        painelPrincipal.add(Box.createVerticalStrut(14));

        painelPrincipal.add(criarCampo("Salário", salario, labelFont, inputFont));
        painelPrincipal.add(Box.createVerticalStrut(25));

        JButton btnCriar = new JButton("Cadastrar");
        btnCriar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnCriar.setBackground(new Color(40, 115, 255));
        btnCriar.setForeground(Color.WHITE);
        btnCriar.setPreferredSize(new Dimension(300, 45));
        btnCriar.setMaximumSize(new Dimension(300, 45));
        btnCriar.setFocusPainted(false);
        btnCriar.setAlignmentX(Component.CENTER_ALIGNMENT); // Centraliza o Botão

        painelPrincipal.add(btnCriar);
        painelPrincipal.add(Box.createVerticalStrut(20));

        // Wrapper para o link "Voltar" garantir centralização perfeita
        JPanel voltarWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER));
        voltarWrapper.setBackground(new Color(245, 245, 245));
        voltarWrapper.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel voltar = new JLabel("<html><u>Voltar ao Dashboard</u></html>");
        voltar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        voltar.setForeground(new Color(40, 115, 255));
        // voltar.setAlignmentX(Component.CENTER_ALIGNMENT); // Não necessário dentro do
        // FlowLayout

        voltarWrapper.add(voltar);
        painelPrincipal.add(voltarWrapper);

        // Ações
        voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CardLayout cl = (CardLayout) container.getLayout();
                cl.show(container, "DASH");
            }
        });

        btnCriar.addActionListener(e -> {
            JOptionPane.showMessageDialog(painelPrincipal,
                    "Usuário cadastrado (exemplo fictício)");
        });
    }

    private JPanel criarCampo(String nome, JComponent input, Font labelFont, Font inputFont) {
        JPanel bloco = new JPanel();
        bloco.setLayout(new BoxLayout(bloco, BoxLayout.Y_AXIS));
        bloco.setBackground(new Color(245, 245, 245));
        bloco.setMaximumSize(new Dimension(350, 65));
        bloco.setAlignmentX(Component.CENTER_ALIGNMENT); // CORREÇÃO: Centraliza o bloco inteiro no painel pai

        JLabel label = new JLabel(nome);
        label.setFont(labelFont);
        label.setAlignmentX(Component.CENTER_ALIGNMENT); // CORREÇÃO: Centraliza o texto dentro do bloco

        input.setFont(inputFont);
        input.setPreferredSize(new Dimension(350, 34));
        input.setMaximumSize(new Dimension(350, 34));
        input.setAlignmentX(Component.CENTER_ALIGNMENT); // CORREÇÃO: Centraliza o input dentro do bloco

        bloco.add(label);
        bloco.add(Box.createVerticalStrut(6));
        bloco.add(input);

        return bloco;
    }

    public JPanel getPanel() {
        return painelPrincipal;
    }
}